package elemenyFactory;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import utilities.baseFunctionality;

import java.io.IOException;

public class sentenceApp {
    public WebDriver driver;

    @FindBy(how = How.XPATH, using = "/html/body/app-root/ion-app/ion-router-outlet/app-sentence-list/ion-header/ion-toolbar/ion-title")
    private WebElement HomepageValidation;
    public void HomepageValidation() throws IOException {
        String LoginValidation = HomepageValidation.getText();
        Assert.assertEquals("Sentences",LoginValidation);
        baseFunctionality.TakeScreenShots("sentence Home Validation");
    }

    @FindBy(how = How.XPATH, using = "/html/body/app-root/ion-app/ion-router-outlet/app-sentence-create/ion-header/ion-toolbar/ion-title")
    private WebElement sentencePageValidation;
    public void sentencePageValidation() throws IOException {
        String sentenceValidation = sentencePageValidation.getText();
        Assert.assertEquals("",sentenceValidation);
        baseFunctionality.TakeScreenShots("sentence Home Validation");
    }


    @FindBy(how = How.XPATH, using = "/html/body/app-root/ion-app/ion-router-outlet/app-sentence-list/ion-content/ion-button")
    private WebElement createSentence;
    public void createSentence() throws IOException {
        createSentence.click();
    }

    @FindBy(how = How.XPATH, using = "/html/body/app-root/ion-app/ion-router-outlet/app-sentence-create/ion-content/ion-card/ion-card-content/ion-input[1]/input")
    private WebElement Name;
    public void Name() throws IOException {
        Name.sendKeys("Test Automation");
    }

    @FindBy(how = How.XPATH, using = "/html/body/app-root/ion-app/ion-router-outlet/app-sentence-create/ion-content/ion-list/ion-item[1]/ion-label")
    private WebElement sentenceSelect;
    public void sentenceSelect() throws IOException {
        sentenceSelect.click();
    }

    @FindBy(how = How.XPATH, using = "/html/body/app-root/ion-app/ion-router-outlet/app-sentence-create/ion-content/ion-card/ion-card-content/ion-button")
    private WebElement SaveSentence;
    public void SaveSentence() throws IOException {
        SaveSentence.click();
    }

    //constructor
    public sentenceApp(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }



}
