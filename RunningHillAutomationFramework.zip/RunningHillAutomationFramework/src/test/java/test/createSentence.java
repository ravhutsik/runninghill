package test;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elemenyFactory.sentenceApp;
import utilities.driverFactory;

import java.io.IOException;

public class createSentence {
    private sentenceApp SentenceElements = new sentenceApp(driverFactory.getDriver());

    @Given("^i have launched the browser$")
    public void iHaveLaunchedTheBrowser() throws IOException {
        driverFactory.getDriver();
        SentenceElements.HomepageValidation();
    }

    @When("^i click on create sentence button$")
    public void iClickOnCreateSentenceButton() throws IOException {
        SentenceElements.createSentence();
    }

    @Then("^i validate if i am on create sentence page$")
    public void iValidateIfIAmOnCreateSentencePage() throws IOException {
        SentenceElements.sentencePageValidation();
    }

    @And("^i capture sentence name$")
    public void iCaptureSentenceName() throws IOException {
        SentenceElements.Name();
    }

    @And("^i click on default sentence$")
    public void iClickOnDefaultSentence() throws IOException {
        SentenceElements.sentenceSelect();
    }

    @And("^i click on save$")
    public void iClickOnSave() throws IOException {
        SentenceElements.SaveSentence();
    }

    @Then("^i validate if the sentence has been created$")
    public void iValidateIfTheSentenceHasBeenCreated() {

    }
}
